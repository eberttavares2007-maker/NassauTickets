# Casos de Uso

## UC01 — Emitir senha
**Ator:** AC  
**Pré-condição:** totem disponível e expediente de emissão aberto.  
**Fluxo:** AC escolhe o tipo → AS gera a numeração → senha é registrada como EMITIDA/AGUARDANDO → senha é exibida ao cliente.

## UC02 — Chamar próxima senha
**Ator:** AA  
**Pré-condição:** AA autenticado e guichê disponível.  
**Fluxo:** AA solicita próxima → AS aplica prioridade → registra chamada → atualiza painel → informa senha e guichê.

## UC03 — Chamar novamente
**Ator:** AA  
**Fluxo:** AA aciona “Chamar Novamente” → AS registra segunda chamada → reproduz áudio com “Última chamada”.

## UC04 — Iniciar atendimento
**Ator:** AA  
**Pré-condição:** senha chamada e cliente presente.  
**Fluxo:** AA inicia → AS registra horário e guichê → estado EM_ATENDIMENTO.

## UC05 — Finalizar atendimento
**Ator:** AA  
**Fluxo:** AA finaliza → AS registra horário de término → estado ATENDIDA.

## UC06 — Abandonar senha
**Ator:** AS  
**Fluxo:** segunda chamada sem comparecimento → estado NÃO_COMPARECEU → senha deixa a fila de atendimento.

## UC07 — Consultar painel
**Ator:** AC  
**Fluxo:** painel consulta histórico → exibe 5 últimas chamadas, sem revelar a próxima senha.

## UC08 — Emitir relatórios
**Ator:** Gestor  
**Fluxo:** gestor autentica → seleciona período/tipo → AS consolida dados → relatório é apresentado.

## UC09 — Gerenciar cadastros
**Ator:** Gestor  
**Fluxo:** gestor autentica → acessa cadastros → inclui/altera dados permitidos → sistema valida e registra auditoria.

## UC10 — Tratar concorrência
**Ator:** AA/AS  
**Fluxo:** dois AA solicitam chamada → backend executa operação atômica → cada senha só pode ser atribuída uma vez.
