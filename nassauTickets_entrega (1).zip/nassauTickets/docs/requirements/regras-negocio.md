# Regras de Negócio

**RN01:** O expediente de chamadas ocorre das 07h às 17h.

**RN02:** Existem três tipos de senha: SP, SG e SE.

**RN03:** SP possui maior prioridade.

**RN04:** SE é uma prioridade operacional especial e deve ser chamada após SP quando disponível.

**RN05:** SG possui menor prioridade.

**RN06:** A sequência de atendimento segue `SP → SE/SG → SP → SE/SG`.

**RN07:** Quando uma fila estiver vazia, o sistema decide a próxima respeitando as prioridades restantes.

**RN08:** Qualquer guichê pode atender qualquer tipo de senha.

**RN09:** Uma senha não atendida após duas chamadas é considerada abandonada/NÃO_COMPARECEU.

**RN10:** Aproximadamente 5% das senhas emitidas não são atendidas, conforme especificação do projeto.

**RN11:** Senhas restantes na fila ao final do expediente são descartadas.

**RN12:** O painel apresenta apenas as cinco últimas senhas chamadas.

**RN13:** A próxima senha não é mostrada no painel.

**RN14:** A sequência numérica reinicia diariamente por prioridade.

**RN15:** O cliente usa o totem anonimamente.

**RN16:** O acesso de atendente exige login.

**RN17:** O perfil gestor é responsável por cadastros e relatórios.

**RN18:** Chamadas simultâneas devem ser tratadas sem duplicidade de senha.

**RN19:** O atendimento deve registrar guichê, início e finalização.

**RN20:** O histórico de auditoria deve registrar as chamadas e os eventos do atendimento.
