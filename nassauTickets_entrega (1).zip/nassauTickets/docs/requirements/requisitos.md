# Requisitos do nassauTickets

## Requisitos Funcionais

**RF01 — Emitir senha:** permitir ao cliente emitir senha anonimamente pelo totem, escolhendo o tipo de atendimento.

**RF02 — Gerar numeração:** gerar senha no padrão `YYMMDD-PPSQ`, com sequência diária de três dígitos por prioridade.

**RF03 — Aguardar fila:** manter senha no estado AGUARDANDO até sua chamada.

**RF04 — Chamar próxima senha:** permitir ao atendente solicitar a próxima senha conforme a política SP → SE/SG → SP → SE/SG.

**RF05 — Chamar novamente:** permitir segunda chamada da senha, repetindo o áudio e indicando “Última chamada”.

**RF06 — Iniciar atendimento:** registrar início do atendimento e guichê.

**RF07 — Finalizar atendimento:** registrar término do atendimento e mudar o estado para ATENDIDA.

**RF08 — Não comparecimento:** após duas chamadas sem comparecimento, alterar a senha para NÃO_COMPARECEU.

**RF09 — Painel:** exibir as 5 últimas senhas chamadas, sem exibir a próxima senha.

**RF10 — Login:** autenticar o agente atendente e permitir perfil adicional de gestor.

**RF11 — Relatórios:** gerar relatórios diário e mensal de emissão, atendimento, prioridades, detalhes, tempo médio e auditoria.

**RF12 — Auditoria:** registrar atendente, guichê, senha, primeira chamada, segunda chamada, início e finalização.

**RF13 — Encerramento:** ao fim do expediente, concluir atendimentos em andamento e descartar senhas restantes.

**RF14 — Áudio:** informar prioridade, senha e guichê durante a chamada.

**RF15 — Concorrência:** impedir que dois atendentes obtenham a mesma próxima senha em chamadas simultâneas.

## Requisitos Não Funcionais

**RNF01 — Segurança:** autenticação para AA/gestor, autorização por perfil e proteção de credenciais.

**RNF02 — LGPD:** minimizar dados pessoais, manter interação do cliente anônima no totem e controlar acesso aos registros.

**RNF03 — Acessibilidade:** interface navegável por teclado, labels, contraste adequado, feedback visual e suporte a leitor de tela.

**RNF04 — Disponibilidade:** frontend e painel devem apresentar estado de indisponibilidade quando backend/banco falharem.

**RNF05 — Desempenho:** chamada de senha deve possuir resposta rápida e não bloquear a fila.

**RNF06 — Auditoria:** ações relevantes devem ser registradas com data/hora.

**RNF07 — Concorrência:** operações de retirada da próxima senha devem ser atômicas/transacionais.

**RNF08 — Manutenibilidade:** separar frontend, backend, serviços e documentação.

**RNF09 — Compatibilidade:** frontend em React e backend compatível com a infraestrutura indicada.

**RNF10 — Integridade:** estados das senhas devem seguir a máquina de estados definida.
