CREATE DATABASE IF NOT EXISTS nassau_tickets;
USE nassau_tickets;

CREATE TABLE usuario (
  id BIGINT PRIMARY KEY AUTO_INCREMENT,
  nome VARCHAR(120) NOT NULL,
  login VARCHAR(80) NOT NULL UNIQUE,
  senha_hash VARCHAR(255) NOT NULL,
  perfil ENUM('ATENDENTE','GESTOR') NOT NULL
);

CREATE TABLE guiche (
  id BIGINT PRIMARY KEY AUTO_INCREMENT,
  numero INT NOT NULL UNIQUE,
  ativo BOOLEAN NOT NULL DEFAULT TRUE
);

CREATE TABLE senha (
  id BIGINT PRIMARY KEY AUTO_INCREMENT,
  numero VARCHAR(20) NOT NULL UNIQUE,
  tipo ENUM('SP','SG','SE') NOT NULL,
  data_emissao DATE NOT NULL,
  hora_emissao DATETIME NOT NULL,
  estado ENUM('EMITIDA','AGUARDANDO','CHAMADA','CHAMADA_NOVAMENTE','EM_ATENDIMENTO','ATENDIDA','NAO_COMPARECEU') NOT NULL,
  hora_atendimento DATETIME NULL,
  guiche_id BIGINT NULL,
  usuario_id BIGINT NULL,
  FOREIGN KEY (guiche_id) REFERENCES guiche(id),
  FOREIGN KEY (usuario_id) REFERENCES usuario(id)
);

CREATE TABLE auditoria_atendimento (
  id BIGINT PRIMARY KEY AUTO_INCREMENT,
  senha_id BIGINT NOT NULL,
  usuario_id BIGINT NOT NULL,
  guiche_id BIGINT NOT NULL,
  primeira_chamada DATETIME NOT NULL,
  segunda_chamada DATETIME NULL,
  inicio_atendimento DATETIME NULL,
  finalizacao DATETIME NULL,
  FOREIGN KEY (senha_id) REFERENCES senha(id),
  FOREIGN KEY (usuario_id) REFERENCES usuario(id),
  FOREIGN KEY (guiche_id) REFERENCES guiche(id)
);
