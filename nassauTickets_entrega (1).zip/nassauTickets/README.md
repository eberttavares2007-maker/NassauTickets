# nassauTickets

Sistema de Controle de Atendimento para um Laboratório de Análises Clínicas.

## Objetivo
Controlar emissão, fila, chamada e atendimento de senhas, respeitando as regras de prioridade definidas no projeto.

## Tecnologias
- Frontend: React 19 + Vite
- Backend: Node.js LTS 22 + Express
- Banco de dados: MySQL 8.0
- Documentação: requisitos, MER e UML

## Estrutura
```text
nassauTickets/
├── backend/
├── docs/
│   ├── branding/
│   ├── mer/
│   ├── mockups/
│   ├── models/
│   │   └── uml/
│   └── requirements/
├── frontend/
├── .gitignore
├── LICENSE
└── README.md
```

## Membros
Preencha com os integrantes, matrícula e papel:
| Nome | Matrícula | Papel |
|---|---|---|
| PREENCHER | PREENCHER | Scrum Master |
| PREENCHER | PREENCHER | Desenvolvedor |
| PREENCHER | PREENCHER | Documentador |
| PREENCHER | PREENCHER | Testador |

## Branches
- `main`: versão integrada/entregável.
- `dev`: desenvolvimento.
- As alterações devem ser feitas primeiro em `dev` e depois integradas por merge em `main`.

## Execução
### Backend
```bash
cd backend
npm install
npm run dev
```

### Frontend
```bash
cd frontend
npm install
npm run dev
```

## Configuração
Crie as variáveis de ambiente do backend conforme o arquivo `.env.example`.

## Regras principais
- Expediente: 07h às 17h.
- Tipos: SP (prioritária), SE (retirada de exames), SG (geral).
- Ordem: SP → SE/SG → SP → SE/SG.
- Qualquer guichê atende qualquer tipo.
- Após duas chamadas sem comparecimento, a senha passa para NÃO_COMPARECEU.
- O painel exibe somente as 5 últimas senhas chamadas.
- Senhas restantes ao fim do expediente são descartadas.
- Numeração: `YYMMDD-PPSQ`, com sequência de 3 dígitos reiniciada diariamente por prioridade.

## Licença
MIT.
