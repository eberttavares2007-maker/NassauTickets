import React, { useEffect, useState } from 'react';

const API = 'http://localhost:3000/api';

export default function App() {
  const [painel, setPainel] = useState([]);
  const [ultima, setUltima] = useState(null);
  const [erro, setErro] = useState('');

  async function atualizarPainel() {
    const r = await fetch(`${API}/painel`);
    setPainel(await r.json());
  }

  async function emitir(tipo) {
    setErro('');
    const r = await fetch(`${API}/senhas`, {
      method: 'POST', headers: {'Content-Type':'application/json'},
      body: JSON.stringify({ tipo })
    });
    const data = await r.json();
    if (!r.ok) return setErro(data.erro);
    setUltima(data);
  }

  async function chamar() {
    setErro('');
    const r = await fetch(`${API}/atendimentos/chamar`, {
      method: 'POST', headers: {'Content-Type':'application/json'},
      body: JSON.stringify({ guiche: 1, atendente: 'AA' })
    });
    const data = await r.json();
    if (!r.ok) return setErro(data.erro);
    setUltima(data);
    atualizarPainel();
  }

  async function acao(id, rota) {
    const r = await fetch(`${API}/atendimentos/${id}/${rota}`, {method:'POST'});
    const data = await r.json();
    if (!r.ok) return setErro(data.erro);
    setUltima(data);
    atualizarPainel();
  }

  useEffect(() => { atualizarPainel(); }, []);

  return (
    <main className="container">
      <header><h1>nassauTickets</h1><p>Sistema de Controle de Atendimento</p></header>

      <section className="card">
        <h2>Totem — Emitir senha</h2>
        <div className="buttons">
          <button onClick={() => emitir('SP')}>Senha Prioritária (SP)</button>
          <button onClick={() => emitir('SE')}>Retirada de Exames (SE)</button>
          <button onClick={() => emitir('SG')}>Senha Geral (SG)</button>
        </div>
        {ultima && <p className="ticket">Última senha: <strong>{ultima.numero}</strong></p>}
      </section>

      <section className="card">
        <h2>Atendente</h2>
        <button onClick={chamar}>Chamar próxima senha</button>
        {ultima && ultima.estado === 'CHAMADA' && (
          <div className="actions">
            <button onClick={() => acao(ultima.id, 'novamente')}>Chamar Novamente</button>
            <button onClick={() => acao(ultima.id, 'iniciar')}>Iniciar atendimento</button>
          </div>
        )}
        {ultima && ultima.estado === 'CHAMADA_NOVAMENTE' && (
          <button onClick={() => acao(ultima.id, 'iniciar')}>Iniciar atendimento</button>
        )}
        {ultima && ultima.estado === 'EM_ATENDIMENTO' && (
          <button onClick={() => acao(ultima.id, 'finalizar')}>Finalizar atendimento</button>
        )}
        {erro && <p className="error" role="alert">{erro}</p>}
      </section>

      <section className="card">
        <h2>Painel — 5 últimas chamadas</h2>
        <ul>{painel.map(s => <li key={s.id}><strong>{s.numero}</strong> — Guichê {s.guiche}</li>)}</ul>
      </section>
    </main>
  );
}
